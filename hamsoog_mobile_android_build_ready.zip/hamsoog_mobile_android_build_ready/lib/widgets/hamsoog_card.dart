import 'package:flutter/material.dart';

import '../theme.dart';

class HamsoogCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;

  const HamsoogCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: HamsoogColors.warmWhite,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: const Color(0xFFEBDDD5)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 22,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: child,
    );
  }
}
