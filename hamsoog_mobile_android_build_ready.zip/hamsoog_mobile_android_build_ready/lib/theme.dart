import 'package:flutter/material.dart';

class HamsoogColors {
  static const cream = Color(0xFFFFF8F1);
  static const warmWhite = Color(0xFFFFFCF8);
  static const brown = Color(0xFF6F4E37);
  static const brownDark = Color(0xFF4A3325);
  static const blush = Color(0xFFE9C8C1);
  static const blushDark = Color(0xFFC7928A);
  static const text = Color(0xFF2D2420);
  static const muted = Color(0xFF84736B);
  static const success = Color(0xFF4E7D63);
  static const danger = Color(0xFFB55B5B);
}

ThemeData hamsoogTheme() {
  return ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: HamsoogColors.blushDark,
      primary: HamsoogColors.brown,
      secondary: HamsoogColors.blushDark,
      surface: HamsoogColors.cream,
    ),
    scaffoldBackgroundColor: HamsoogColors.cream,
    fontFamily: null,
    appBarTheme: const AppBarTheme(
      backgroundColor: HamsoogColors.cream,
      foregroundColor: HamsoogColors.text,
      centerTitle: true,
      elevation: 0,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: HamsoogColors.warmWhite,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: const BorderSide(color: Color(0xFFEBDDD5)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: const BorderSide(color: HamsoogColors.brown, width: 1.4),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: HamsoogColors.brown,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 22),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: HamsoogColors.brown,
        side: const BorderSide(color: HamsoogColors.blushDark),
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 22),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
    ),
  );
}
