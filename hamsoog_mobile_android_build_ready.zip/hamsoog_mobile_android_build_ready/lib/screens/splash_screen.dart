import 'dart:async';

import 'package:flutter/material.dart';

import '../theme.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  static const route = '/';
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 1200), () {
      if (mounted) Navigator.pushReplacementNamed(context, HomeScreen.route);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset('assets/images/hamsoog_logo.png', width: 128),
            const SizedBox(height: 18),
            Text(
              'همسوگ',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    color: HamsoogColors.brownDark,
                    fontWeight: FontWeight.w900,
                  ),
            ),
            const SizedBox(height: 8),
            Text(
              'همراهی آرام، انسانی و تخصصی در مسیر سوگ',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: HamsoogColors.muted,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
