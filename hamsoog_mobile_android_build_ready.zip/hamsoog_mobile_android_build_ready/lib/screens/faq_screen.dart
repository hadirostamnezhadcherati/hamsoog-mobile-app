import 'package:flutter/material.dart';

import '../widgets/hamsoog_card.dart';
import '../widgets/section_title.dart';

class FaqScreen extends StatelessWidget {
  static const route = '/faq';
  const FaqScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('سوالات رایج')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: const [
            SectionTitle(title: 'سوالات رایج', subtitle: 'پاسخ‌ها کوتاه، آرام و بدون فشار فروش نوشته شده‌اند.'),
            SizedBox(height: 18),
            _FaqItem(q: 'آیا برای شروع باید ثبت‌نام کنم؟', a: 'خیر. می‌توانید اپ را ببینید. فقط هنگام ثبت درخواست یا پیگیری پذیرش، شماره موبایل برای تماس کارشناسان و امنیت اطلاعات دریافت می‌شود.'),
            _FaqItem(q: 'بعد از ثبت درخواست چه می‌شود؟', a: 'درخواست شما ثبت می‌شود و کارشناسان همسوگ با شما تماس می‌گیرند.'),
            _FaqItem(q: 'موضوع همراهی فعلی چیست؟', a: 'در نسخه فعلی، تمرکز پذیرش اپ روی سوگ سقط جنین است.'),
          ],
        ),
      ),
    );
  }
}

class _FaqItem extends StatelessWidget {
  final String q;
  final String a;
  const _FaqItem({required this.q, required this.a});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: HamsoogCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(q, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text(a, style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.9)),
          ],
        ),
      ),
    );
  }
}
