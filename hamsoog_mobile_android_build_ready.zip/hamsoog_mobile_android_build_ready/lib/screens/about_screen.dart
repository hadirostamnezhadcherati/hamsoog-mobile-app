import 'package:flutter/material.dart';

import '../theme.dart';
import '../widgets/hamsoog_card.dart';
import '../widgets/section_title.dart';
import 'internal_login_screen.dart';

class AboutScreen extends StatefulWidget {
  static const route = '/about';
  const AboutScreen({super.key});

  @override
  State<AboutScreen> createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen> {
  int _secretTapCount = 0;

  void _handleSecretTap() {
    _secretTapCount += 1;
    if (_secretTapCount >= 5) {
      _secretTapCount = 0;
      Navigator.pushNamed(context, InternalLoginScreen.route);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('درباره همسوگ')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Center(
              child: GestureDetector(
                onTap: _handleSecretTap,
                child: Image.asset('assets/images/hamsoog_logo.png', width: 92),
              ),
            ),
            const SizedBox(height: 18),
            const SectionTitle(
              title: 'همسوگ',
              subtitle: 'همسوگ با رویکردی حرفه‌ای و انسانی به شما کمک می‌کند تا در مسیر سوگ احساسات خود را بهتر بشناسید، با خودتان مهربان‌تر باشید و با حمایت تخصصی گام‌به‌گام به سوی زندگی آرام‌تر و معنادار حرکت کنید.',
            ),
            const SizedBox(height: 18),
            HamsoogCard(
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: Image.asset('assets/images/mobina_esmaeili.jpg', width: 88, height: 88, fit: BoxFit.cover),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text('مبینا اسماعیلی', style: TextStyle(fontWeight: FontWeight.w900, color: HamsoogColors.brownDark, fontSize: 17)),
                        SizedBox(height: 6),
                        Text('همراه و کوچ در مسیر سوگ، با آموزش‌های EFT، Grief Care و Professional Coaching.', style: TextStyle(color: HamsoogColors.muted, height: 1.7)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
