import 'package:flutter/material.dart';

import '../theme.dart';
import '../widgets/hamsoog_card.dart';
import '../widgets/section_title.dart';

class InternalLoginScreen extends StatefulWidget {
  static const route = '/internal-login';
  const InternalLoginScreen({super.key});

  @override
  State<InternalLoginScreen> createState() => _InternalLoginScreenState();
}

class _InternalLoginScreenState extends State<InternalLoginScreen> {
  final _mobile = TextEditingController();
  final _code = TextEditingController();
  bool _otpStep = false;

  @override
  void dispose() {
    _mobile.dispose();
    _code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ورود امن')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SectionTitle(
              title: 'ورود امن همسوگ',
              subtitle: 'این بخش فقط برای کاربران داخلی فعال است. نقش کاربر از سمت سرور تشخیص داده می‌شود.',
            ),
            const SizedBox(height: 18),
            HamsoogCard(
              child: Column(
                children: [
                  TextField(
                    controller: _mobile,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(labelText: 'شماره موبایل کاربر داخلی'),
                  ),
                  if (_otpStep) ...[
                    const SizedBox(height: 12),
                    TextField(
                      controller: _code,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'کد تایید'),
                    ),
                  ],
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () {
                        setState(() => _otpStep = true);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('بعد از ساخت API، کد فقط برای شماره‌های داخلی مجاز ارسال می‌شود.')),
                        );
                      },
                      child: Text(_otpStep ? 'تایید و ورود' : 'ارسال کد تایید'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'در نسخه نهایی، اگر شماره در users با نقش seller/accountant/admin فعال نباشد، ورود انجام نمی‌شود.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: HamsoogColors.muted, height: 1.7),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
