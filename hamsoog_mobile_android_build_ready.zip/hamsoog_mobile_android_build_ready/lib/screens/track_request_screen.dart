import 'package:flutter/material.dart';

import '../theme.dart';
import '../widgets/hamsoog_card.dart';
import '../widgets/section_title.dart';

class TrackRequestScreen extends StatelessWidget {
  static const route = '/track-request';
  const TrackRequestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final mobile = TextEditingController();
    return Scaffold(
      appBar: AppBar(title: const Text('پیگیری درخواست')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SectionTitle(
              title: 'پیگیری پذیرش',
              subtitle: 'برای حفظ امنیت اطلاعات، وضعیت درخواست فقط بعد از تایید شماره موبایل نمایش داده می‌شود.',
            ),
            const SizedBox(height: 18),
            HamsoogCard(
              child: Column(
                children: [
                  TextField(
                    controller: mobile,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(labelText: 'شماره موبایل'),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () {},
                      child: const Text('دریافت کد پیگیری'),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'این بخش بعد از ساخت API پیگیری، به جدول پذیرش و فاکتورهای همسوگ وصل می‌شود.',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(color: HamsoogColors.muted, height: 1.8),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
