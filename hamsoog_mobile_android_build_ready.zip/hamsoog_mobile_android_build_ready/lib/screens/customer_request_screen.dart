import 'package:flutter/material.dart';

import '../services/api_client.dart';
import '../theme.dart';
import '../widgets/hamsoog_card.dart';
import '../widgets/section_title.dart';

class CustomerRequestScreen extends StatefulWidget {
  static const route = '/customer-request';
  const CustomerRequestScreen({super.key});

  @override
  State<CustomerRequestScreen> createState() => _CustomerRequestScreenState();
}

class _CustomerRequestScreenState extends State<CustomerRequestScreen> {
  final _formKey = GlobalKey<FormState>();
  final _api = ApiClient();
  final _name = TextEditingController();
  final _mobile = TextEditingController();
  final _city = TextEditingController();
  final _description = TextEditingController();
  final _whatsapp = TextEditingController();
  bool _isInternational = false;
  bool _loading = false;
  String? _message;

  @override
  void dispose() {
    _name.dispose();
    _mobile.dispose();
    _city.dispose();
    _description.dispose();
    _whatsapp.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _message = null;
    });

    try {
      await _api.postJson('/customer/request/start', {
        'full_name': _name.text.trim(),
        'mobile': _mobile.text.trim(),
        'city': _city.text.trim(),
        'grief_type': 'سقط جنین',
        'description': _description.text.trim(),
        'is_international': _isInternational,
        'whatsapp_number': _whatsapp.text.trim(),
      });
      if (!mounted) return;
      setState(() => _message = 'کد تایید برای شما ارسال شد. در مرحله بعد ثبت درخواست کامل می‌شود.');
    } on Object catch (_) {
      if (!mounted) return;
      setState(() => _message = 'فعلاً اتصال به API فعال نشده است. فرم آماده است و بعد از ساخت API به پنل همسوگ وصل می‌شود.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('درخواست همراهی')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SectionTitle(
              title: 'ثبت اطلاعات تماس',
              subtitle: 'برای اینکه کارشناسان همسوگ بتوانند با شما تماس بگیرند، لطفاً اطلاعات تماس خود را ثبت کنید.',
            ),
            const SizedBox(height: 18),
            HamsoogCard(
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    TextFormField(
                      controller: _name,
                      textInputAction: TextInputAction.next,
                      decoration: const InputDecoration(labelText: 'نام و نام خانوادگی'),
                      validator: (value) => value == null || value.trim().isEmpty ? 'نام را وارد کنید' : null,
                    ),
                    const SizedBox(height: 12),
                    SwitchListTile(
                      value: _isInternational,
                      contentPadding: EdgeInsets.zero,
                      title: const Text('خارج از کشور هستم / تماس واتس‌اپی'),
                      activeColor: HamsoogColors.brown,
                      onChanged: (value) => setState(() => _isInternational = value),
                    ),
                    const SizedBox(height: 12),
                    if (!_isInternational)
                      TextFormField(
                        controller: _mobile,
                        keyboardType: TextInputType.phone,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(labelText: 'شماره موبایل'),
                        validator: (value) {
                          final v = value?.trim() ?? '';
                          if (v.isEmpty) return 'شماره موبایل را وارد کنید';
                          if (!RegExp(r'^09\d{9}$').hasMatch(v)) return 'شماره موبایل را صحیح وارد کنید';
                          return null;
                        },
                      ),
                    if (_isInternational)
                      TextFormField(
                        controller: _whatsapp,
                        keyboardType: TextInputType.phone,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(labelText: 'شماره واتس‌اپ'),
                        validator: (value) => value == null || value.trim().isEmpty ? 'شماره واتس‌اپ را وارد کنید' : null,
                      ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _city,
                      textInputAction: TextInputAction.next,
                      decoration: const InputDecoration(labelText: 'شهر'),
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      initialValue: 'سقط جنین',
                      readOnly: true,
                      decoration: const InputDecoration(labelText: 'موضوع همراهی'),
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _description,
                      minLines: 3,
                      maxLines: 5,
                      decoration: const InputDecoration(labelText: 'توضیح کوتاه، در صورت تمایل'),
                    ),
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: _loading ? null : _submit,
                        child: Text(_loading ? 'در حال ثبت...' : 'ثبت و دریافت کد تایید'),
                      ),
                    ),
                    if (_message != null) ...[
                      const SizedBox(height: 14),
                      Text(
                        _message!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: HamsoogColors.muted, height: 1.7),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
