import 'package:flutter/material.dart';

import '../theme.dart';
import '../widgets/hamsoog_card.dart';
import '../widgets/section_title.dart';
import 'customer_request_screen.dart';

class CourseScreen extends StatelessWidget {
  static const route = '/courses';
  const CourseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('دوره‌های همسوگ')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SectionTitle(
              title: 'مسیرهای همراهی',
              subtitle: 'اینجا قیمت نمایش داده نمی‌شود. تمرکز اپ روی آرام‌سازی، اعتماد و هدایت به ثبت درخواست است.',
            ),
            const SizedBox(height: 18),
            _CourseCard(
              title: 'دوره همراهی سوگ',
              desc: 'همراهی گام‌به‌گام برای عبور آگاهانه، مدیریت احساسات و یافتن تعادل دوباره.',
            ),
            const SizedBox(height: 14),
            _CourseCard(
              title: 'دوره التیام عمیق سوگ',
              desc: 'مسیر عمیق‌تری برای رهایی از دردهای پنهان، بازسازی و التیام ماندگار.',
            ),
          ],
        ),
      ),
    );
  }
}

class _CourseCard extends StatelessWidget {
  final String title;
  final String desc;

  const _CourseCard({required this.title, required this.desc});

  @override
  Widget build(BuildContext context) {
    return HamsoogCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900, color: HamsoogColors.brownDark)),
          const SizedBox(height: 8),
          Text(desc, style: const TextStyle(color: HamsoogColors.muted, height: 1.9)),
          const SizedBox(height: 14),
          OutlinedButton(
            onPressed: () => Navigator.pushNamed(context, CustomerRequestScreen.route),
            child: const Text('درخواست تماس کارشناسان'),
          ),
        ],
      ),
    );
  }
}
