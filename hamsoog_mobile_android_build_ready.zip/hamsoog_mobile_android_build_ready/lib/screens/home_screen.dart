import 'package:flutter/material.dart';

import '../theme.dart';
import '../widgets/hamsoog_card.dart';
import 'about_screen.dart';
import 'course_screen.dart';
import 'customer_request_screen.dart';
import 'faq_screen.dart';
import 'track_request_screen.dart';

class HomeScreen extends StatelessWidget {
  static const route = '/home';
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
          children: [
            Row(
              children: [
                Image.asset('assets/images/hamsoog_logo.png', width: 58),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'همسوگ',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.w900,
                          color: HamsoogColors.brownDark,
                        ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            ClipRRect(
              borderRadius: BorderRadius.circular(30),
              child: Stack(
                alignment: Alignment.bottomRight,
                children: [
                  Image.asset(
                    'assets/images/hamsoog_cover_mobile.png',
                    height: 280,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(22),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0x00000000), Color(0xAA3A261D)],
                      ),
                    ),
                    child: Text(
                      'اینجا قرار نیست درد شما کوچک شمرده شود؛ فقط قرار است تنها نمانید.',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            color: Colors.white,
                            height: 1.7,
                            fontWeight: FontWeight.w800,
                          ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            HamsoogCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'همراهی آرام، انسانی و تخصصی در مسیر سوگ',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          color: HamsoogColors.brownDark,
                          fontWeight: FontWeight.w900,
                          height: 1.5,
                        ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'برای شروع، لازم نیست وارد حساب کاربری شوید. هر زمان بخواهید درخواست همراهی ثبت کنید، اطلاعات تماس از شما گرفته می‌شود.',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: HamsoogColors.muted,
                          height: 1.9,
                        ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () => Navigator.pushNamed(context, CustomerRequestScreen.route),
                      child: const Text('درخواست همراهی'),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            _HomeButton(
              icon: Icons.local_florist_outlined,
              title: 'آشنایی با دوره‌ها',
              onTap: () => Navigator.pushNamed(context, CourseScreen.route),
            ),
            _HomeButton(
              icon: Icons.search_outlined,
              title: 'پیگیری درخواست',
              onTap: () => Navigator.pushNamed(context, TrackRequestScreen.route),
            ),
            _HomeButton(
              icon: Icons.favorite_border,
              title: 'درباره همسوگ',
              onTap: () => Navigator.pushNamed(context, AboutScreen.route),
            ),
            _HomeButton(
              icon: Icons.help_outline,
              title: 'سوالات رایج',
              onTap: () => Navigator.pushNamed(context, FaqScreen.route),
            ),
          ],
        ),
      ),
    );
  }
}

class _HomeButton extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _HomeButton({required this.icon, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Ink(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
          decoration: BoxDecoration(
            color: HamsoogColors.warmWhite,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFEBDDD5)),
          ),
          child: Row(
            children: [
              Icon(icon, color: HamsoogColors.brown),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: HamsoogColors.text,
                        fontWeight: FontWeight.w700,
                      ),
                ),
              ),
              const Icon(Icons.chevron_left, color: HamsoogColors.muted),
            ],
          ),
        ),
      ),
    );
  }
}
