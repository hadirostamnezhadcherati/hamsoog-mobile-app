import 'package:flutter/material.dart';

import 'theme.dart';
import 'screens/about_screen.dart';
import 'screens/course_screen.dart';
import 'screens/customer_request_screen.dart';
import 'screens/faq_screen.dart';
import 'screens/home_screen.dart';
import 'screens/internal_login_screen.dart';
import 'screens/splash_screen.dart';
import 'screens/track_request_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const HamsoogApp());
}

class HamsoogApp extends StatelessWidget {
  const HamsoogApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'همسوگ',
      debugShowCheckedModeBanner: false,
      theme: hamsoogTheme(),
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      initialRoute: SplashScreen.route,
      routes: {
        SplashScreen.route: (_) => const SplashScreen(),
        HomeScreen.route: (_) => const HomeScreen(),
        CustomerRequestScreen.route: (_) => const CustomerRequestScreen(),
        TrackRequestScreen.route: (_) => const TrackRequestScreen(),
        CourseScreen.route: (_) => const CourseScreen(),
        AboutScreen.route: (_) => const AboutScreen(),
        FaqScreen.route: (_) => const FaqScreen(),
        InternalLoginScreen.route: (_) => const InternalLoginScreen(),
      },
    );
  }
}
