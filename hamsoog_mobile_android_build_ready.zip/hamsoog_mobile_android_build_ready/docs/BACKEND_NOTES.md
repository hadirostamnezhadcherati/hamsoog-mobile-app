# Backend Notes From Uploaded PHP

بر اساس فایل‌های آپلودشده، پنل فعلی شامل بخش‌های زیر است:

- `users.php`: مدیریت کاربران داخلی
- `login.php`: ورود کاربران داخلی با نام کاربری/رمز و OTP کاوه‌نگار
- `index.php`: ثبت درخواست عمومی مشتری
- `sales.php`: سیستم فروش و مدیریت لید فروشنده
- `invoice_new.php` و `manual_invoice.php`: ثبت فاکتور
- `accounting.php`: بررسی و تایید/رد پرداخت
- `customer_history.php` و `reception.php`: مشخصات پذیرش و تاریخچه
- `reports.php`، `performance.php`، `bonuses.php`: گزارش‌ها و پاداش‌ها
- `includes/functions.php`: هسته منطق، پیامک، تقسیم لید، فاکتور، تاریخ شمسی، امنیت

برای اپ موبایل، نباید مستقیم صفحه‌های PHP فعلی را WebView کنیم. باید یک لایه API سبک روی همین منطق ساخته شود.

## نیاز ضروری بعدی

برای اتصال امن و بدون خطا، فایل Export دیتابیس لازم است:

`hamsoog_database.sql`

از مسیر cPanel → phpMyAdmin → Export → Quick → SQL.
