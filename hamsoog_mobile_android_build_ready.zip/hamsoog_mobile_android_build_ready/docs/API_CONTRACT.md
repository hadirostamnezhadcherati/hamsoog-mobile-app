# Hamsoog Mobile API Contract v1

Base URL پیشنهادی:

`https://panel.hamsoog.com/api/mobile/v1`

## Customer

### POST /customer/request/start
ثبت اولیه درخواست مشتری و ارسال OTP.

Body:
```json
{
  "full_name": "...",
  "mobile": "09123456789",
  "city": "تهران",
  "grief_type": "سقط جنین",
  "description": "...",
  "is_international": false,
  "whatsapp_number": ""
}
```

Response:
```json
{
  "ok": true,
  "request_id": 123,
  "message": "کد تایید ارسال شد."
}
```

### POST /customer/request/verify
تایید OTP و ثبت نهایی/فعال شدن پیگیری.

Body:
```json
{
  "mobile": "09123456789",
  "code": "123456"
}
```

### POST /customer/track/start
ارسال OTP برای پیگیری پذیرش با موبایل.

### POST /customer/track/verify
تایید OTP و بازگشت آخرین وضعیت درخواست‌ها و فاکتورها.

## Internal Auth

### POST /internal/auth/start
ورود داخلی مخفی. فقط شماره‌های موجود در جدول users با role معتبر مجازند.

Body:
```json
{
  "mobile": "09123456789"
}
```

Response:
```json
{
  "ok": true,
  "masked_mobile": "0912***6789"
}
```

### POST /internal/auth/verify
تایید OTP و بازگشت نقش و توکن.

Response:
```json
{
  "ok": true,
  "token": "secure_token",
  "user": {
    "name": "...",
    "role": "seller"
  }
}
```

Roleها:
- `seller`
- `accountant`
- `admin`

## Seller

### GET /seller/leads
لیست لیدهای فروشنده.

### POST /seller/leads/request-batch
دریافت بسته ۵تایی شماره.

### POST /seller/leads/{id}/status
ثبت وضعیت تماس: `answered`, `no_answer`, `follow_up`, `cancelled`, `has_invoice`.

### POST /seller/invoices
ثبت فاکتور جدید.

## Accountant

### GET /accountant/invoices
فاکتورهای جدید و در انتظار بررسی.

### POST /accountant/invoices/{id}/approve
تایید پرداخت.

### POST /accountant/invoices/{id}/reject
رد پرداخت همراه علت.

## Admin

### GET /admin/dashboard
آمار کلی فروش، لید، فاکتور، عملکرد فروشندگان.

### GET /admin/users
مدیریت کاربران داخلی.

### GET /admin/receptions/search?mobile=...
مشخصات پذیرش و تاریخچه مشتری.
