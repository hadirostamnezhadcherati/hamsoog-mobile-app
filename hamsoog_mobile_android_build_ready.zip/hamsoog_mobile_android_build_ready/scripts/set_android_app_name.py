from pathlib import Path

manifest = Path('android/app/src/main/AndroidManifest.xml')
if not manifest.exists():
    raise SystemExit('AndroidManifest.xml not found. Run flutter create first.')

text = manifest.read_text(encoding='utf-8')
# Flutter template usually uses android:label="hamsoog_mobile".
text = text.replace('android:label="hamsoog_mobile"', 'android:label="همسوگ"')
text = text.replace('android:label="hamsoog_mobile_flutter_v1"', 'android:label="همسوگ"')
text = text.replace('android:label="hamsoog_mobile_android_build_ready"', 'android:label="همسوگ"')
manifest.write_text(text, encoding='utf-8')
print('Android app name set to: همسوگ')
