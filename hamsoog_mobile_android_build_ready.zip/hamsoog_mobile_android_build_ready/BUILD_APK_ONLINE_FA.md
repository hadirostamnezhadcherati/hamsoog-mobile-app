# راهنمای ساخت APK اندروید همسوگ با گوشی

این بسته برای ساخت فایل نصب اندروید آماده شده است. این فایل را داخل cPanel یا پوشه‌های سایت/پنل آپلود نکنید؛ این فقط سورس اپ موبایل است.

## خروجی مورد نظر
بعد از Build، فایل نصب اینجاست:

`app-debug.apk`

این نسخه برای تست روی گوشی است، نه انتشار رسمی در Google Play.

## روش پیشنهادی با GitHub Actions

1. داخل GitHub یک Repository جدید بسازید.
2. فایل ZIP را Extract کنید و محتویات پوشه `hamsoog_mobile_android_build_ready` را داخل Repository آپلود کنید.
3. وارد تب `Actions` شوید.
4. Workflow با نام `Build Hamsoog Android APK` را انتخاب کنید.
5. روی `Run workflow` بزنید.
6. بعد از تمام شدن Build، پایین صفحه بخش `Artifacts` را باز کنید.
7. فایل `hamsoog-android-debug-apk` را دانلود کنید.
8. داخل آن، فایل `app-debug.apk` قرار دارد.
9. فایل APK را به گوشی منتقل و نصب کنید.

## روش جایگزین با Codemagic

1. پروژه را در Codemagic به GitHub وصل کنید.
2. Codemagic فایل `codemagic.yaml` را می‌خواند.
3. Workflow به نام `Hamsoog Android Debug APK` را Run کنید.
4. خروجی `app-debug.apk` را از Artifacts دانلود کنید.

## نکته مهم

این نسخه هنوز API واقعی پنل را تغییر نمی‌دهد. فرم‌ها آماده‌اند اما اتصال نهایی به پنل همسوگ بعد از دریافت فایل دیتابیس SQL ساخته می‌شود.
